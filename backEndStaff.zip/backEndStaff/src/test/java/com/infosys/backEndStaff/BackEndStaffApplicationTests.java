package com.infosys.backEndStaff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndStaffApplicationTests {

	@Test
	void contextLoads() {
	}

}
