package com.infosys.backEndStaff.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

public class District {
	
	  @Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY) 
	  @Column(name = "IDDISTRICT")
	  private Integer iddistrict;
	
	  @Column(name="DISTRICTNAME",nullable = false, unique = true)
	  private String districtName;
	
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	  @JoinColumn(name = "IDBLOCK")
	  private List <Block> blockList;
	  
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
		@JoinColumn(name = "IDVILLAGE")
		private List <Village> villageList;

	public Integer getIddistrict() {
		return iddistrict;
	}

	public void setIddistrict(Integer iddistrict) {
		this.iddistrict = iddistrict;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public List<Block> getBlockList() {
		return blockList;
	}

	public void setBlockList(List<Block> blockList) {
		this.blockList = blockList;
	}

	public List<Village> getVillageList() {
		return villageList;
	}

	public void setVillageList(List<Village> villageList) {
		this.villageList = villageList;
	}
	  

	

}
