package com.infosys.backEndStaff.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

public class Village {
	
	  @Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY) 
	  @Column(name = "IDVILLAGE")
	  private Integer idvillage;
	
	  @Column(name="VILLAGENAME",nullable = false, unique = true)
	  private String villageName;
	  
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
		@JoinColumn(name = "idSeniorCitizen")
		private List <SeniorCitizen> seniorCitizenList;

	public Integer getIdvillage() {
		return idvillage;
	}

	public void setIdvillage(Integer idvillage) {
		this.idvillage = idvillage;
	}

	public String getVillageName() {
		return villageName;
	}

	public void setVillageName(String villageName) {
		this.villageName = villageName;
	}

	public List<SeniorCitizen> getSeniorCitizenList() {
		return seniorCitizenList;
	}

	public void setSeniorCitizenList(List<SeniorCitizen> seniorCitizenList) {
		this.seniorCitizenList = seniorCitizenList;
	}
		
	

}
