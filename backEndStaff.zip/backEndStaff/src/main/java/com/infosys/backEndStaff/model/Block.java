package com.infosys.backEndStaff.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

public class Block {
	
	  @Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY) 
	  @Column(name = "IDBLOCK")
	  private Integer idblock;
	
	  @Column(name="BLOCKNAME",nullable = false, unique = true)
	  private String blockName;
	  
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
		@JoinColumn(name = "IDVILLAGE")
		private List <Village> villageList;
	  
	
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
		@JoinColumn(name = "idvolunteer")
		private List <Volunteer> volunteerList;
	  
	  public Integer getIdblock() {
		return idblock;
	}

	public void setIdblock(Integer idblock) {
		this.idblock = idblock;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public List<Village> getVillageList() {
		return villageList;
	}

	public void setVillageList(List<Village> villageList) {
		this.villageList = villageList;
	}

	public List<Volunteer> getVolunteerList() {
		return volunteerList;
	}

	public void setVolunteerList(List<Volunteer> volunteerList) {
		this.volunteerList = volunteerList;
	}

	public List<SeniorCitizen> getSeniorCitizenList() {
		return seniorCitizenList;
	}

	public void setSeniorCitizenList(List<SeniorCitizen> seniorCitizenList) {
		this.seniorCitizenList = seniorCitizenList;
	}

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
		@JoinColumn(name = "idSeniorCitizen")
		private List <SeniorCitizen> seniorCitizenList;
		
		
}
