package com.infosys.backEndStaff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndStaffApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndStaffApplication.class, args);
	}

}
