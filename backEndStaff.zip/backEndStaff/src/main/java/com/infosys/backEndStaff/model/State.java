package com.infosys.backEndStaff.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

public class State {
	
	  @Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY) 
	  @Column(name = "IDSTATE")
	  
	  private Integer idstate;

	
	  @Column(name="STATENAME",nullable = false, unique = true)
	  private String stateName;
	  
	  
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	  @JoinColumn(name = "IDDISTRICT")
	  private List <District> districtList;

	  
	  
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	  @JoinColumn(name = "IDBLOCK")
	  private List <Block> blockList;

	  
	  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	  @JoinColumn(name = "IDVILLAGE")
	  private List <Village> villageList;


	public Integer getIdstate() {
		return idstate;
	}


	public void setIdstate(Integer idstate) {
		this.idstate = idstate;
	}


	public String getStateName() {
		return stateName;
	}


	public void setStateName(String stateName) {
		this.stateName = stateName;
	}


	public List<District> getDistrictList() {
		return districtList;
	}


	public void setDistrictList(List<District> districtList) {
		this.districtList = districtList;
	}


	public List<Block> getBlockList() {
		return blockList;
	}


	public void setBlockList(List<Block> blockList) {
		this.blockList = blockList;
	}


	public List<Village> getVillageList() {
		return villageList;
	}


	public void setVillageList(List<Village> villageList) {
		this.villageList = villageList;
	}
	  
	  
	  
	  
	
	  

}
