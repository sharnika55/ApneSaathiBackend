package com.infosys.backEndStaff.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

//manages more than one district
public class ProgramLeader {

	@Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY) 
	  @Column(name = "IDPROGRAMLEADER")
	  
	  private Integer idprogramleader;
 
	
	  @Column(name="MOBILENO",nullable = false, unique = true)
	  private String phoneNo;
	
	  @Column(name="FIRSTNAME")
	  private String firstName;

	  @Column(name="LASTNAME")
	  private String lastName;
	
	  @Column(name="EMAIL")
	  private String email;
	
	  @Column(name="GENDER")
	  private String gender;
	
	  @Column(name="STATE")
	  private String State;
	
	  @Column(name="DISTRICT")
	  private String District;
	
	  @Column(name="BLOCK_NAME")
	  private String Block;
	
	  public Integer getIdprogramleader() {
		return idprogramleader;
	}



	public void setIdprogramleader(Integer idprogramleader) {
		this.idprogramleader = idprogramleader;
	}



	public String getPhoneNo() {
		return phoneNo;
	}



	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getState() {
		return State;
	}



	public void setState(String state) {
		State = state;
	}



	public String getDistrict() {
		return District;
	}



	public void setDistrict(String district) {
		District = district;
	}



	public String getBlock() {
		return Block;
	}



	public void setBlock(String block) {
		Block = block;
	}



	public String getAddress() {
		return Address;
	}



	public void setAddress(String address) {
		Address = address;
	}



	public String getVillage() {
		return Village;
	}



	public void setVillage(String village) {
		Village = village;
	}



	public List<District> getDistrictList() {
		return districtList;
	}



	public void setDistrictList(List<District> districtList) {
		this.districtList = districtList;
	}



	@Column(name="ADDRESS")
	  private String Address;
	
	  @Column(name="VILLAGE")
	  private String Village;

	 
	 
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "IDDISTRICT")
	private List <District> districtList;


}
